import tkinter as tk
from tkinter import messagebox
from algoritmos.data_manager import DataManager


class InputOptionsScreen(tk.Toplevel):
    def __init__(self, master, data_manager: DataManager, next_callback):
        super().__init__(master)

        self.dm = data_manager
        self.next_callback = next_callback

        self.title("Ingreso de Datos")
        self.geometry("600x400")
        self.configure(bg="#f6f1e7")
        self.resizable(False, False)

        self._center()
        self.create_widgets()

    def _center(self):
        x = (self.winfo_screenwidth() - 600) // 2
        y = (self.winfo_screenheight() - 400) // 2
        self.geometry(f"600x400+{x}+{y}")

    def create_widgets(self):
        tk.Label(
            self,
            text="INGRESO DE DATOS",
            font=("Helvetica", 18, "bold"),
            bg="#f6f1e7"
        ).pack(pady=20)

        tk.Label(self, text="Manual (separados por coma):", bg="#f6f1e7").pack()
        self.manual_entry = tk.Entry(self, width=50)
        self.manual_entry.pack(pady=5)

        tk.Button(
            self,
            text="Cargar Manual",
            command=self._manual
        ).pack(pady=10)

        tk.Label(self, text="Aleatorio (cantidad):", bg="#f6f1e7").pack()
        self.random_entry = tk.Entry(self, width=15)
        self.random_entry.pack(pady=5)

        tk.Button(
            self,
            text="Generar Aleatorio",
            command=self._random
        ).pack(pady=10)

    def _manual(self):
        try:
            self.dm.set_data_manual(self.manual_entry.get())
            messagebox.showinfo("OK", "Datos cargados correctamente")
            self._next()
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def _random(self):
        try:
            count = int(self.random_entry.get())
            self.dm.set_data_random(count)
            messagebox.showinfo("OK", "Datos generados correctamente")
            self._next()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _next(self):
        self.destroy()
        self.next_callback()


