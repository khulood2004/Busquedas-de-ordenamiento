import tkinter as tk
from algoritmos.data_manager import DataManager


class OrderChoiceScreen(tk.Toplevel):
    def __init__(self, master, data_manager: DataManager, next_callback):
        super().__init__(master)

        self.dm = data_manager
        self.next_callback = next_callback

        self.title("Orden de Datos")
        self.geometry("500x300")
        self.configure(bg="#f6f1e7")
        self.resizable(False, False)

        self._center()
        self.create_widgets()

    def _center(self):
        x = (self.winfo_screenwidth() - 500) // 2
        y = (self.winfo_screenheight() - 300) // 2
        self.geometry(f"500x300+{x}+{y}")

    def create_widgets(self):
        tk.Label(
            self,
            text="Seleccione el estado de los datos",
            font=("Helvetica", 14, "bold"),
            bg="#f6f1e7"
        ).pack(pady=30)

        tk.Button(
            self,
            text="Datos Ordenados",
            width=20,
            command=lambda: self._select("ordered")
        ).pack(pady=10)

        tk.Button(
            self,
            text="Datos Desordenados",
            width=20,
            command=lambda: self._select("unordered")
        ).pack(pady=10)

    def _select(self, mode):
        self.dm.set_order_mode(mode)
        self.destroy()
        self.next_callback()
